package com.example.finaltask;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.util.ArrayList;

public class ShowImagesActivity2 extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener{

    private DatabaseHandler1 objectDatabaseHandler1;
    private RecyclerView objectRecyclerView1;
    private ArrayList<ModelClass> objectModelClassList1;
    private RVAdapter1 objectRvAdpater1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_images2);
        fetchAllNotesFromDatabase();
        try
        {
            objectRecyclerView1= findViewById(R.id.imagesRV1);
            objectDatabaseHandler1 = new DatabaseHandler1(this);
            objectModelClassList1 = new ArrayList<ModelClass>();

            objectRecyclerView1.setLayoutManager(new LinearLayoutManager(this));
            objectRvAdpater1 = new RVAdapter1(this,ShowImagesActivity2.this,objectDatabaseHandler1.getAllImagesData());
            // objectRecyclerView.setHasFixedSize(true);
            objectRecyclerView1.setAdapter(objectRvAdpater1);
        }


        catch (Exception e)
        {

        }
    }

    public void getData(View view)
    {
        try
        {
            objectRvAdpater1 = new RVAdapter1(this,ShowImagesActivity2.this,objectDatabaseHandler1.getAllImagesData());
            objectRecyclerView1.setHasFixedSize(true);
            objectRecyclerView1.setLayoutManager(new LinearLayoutManager(this));
            objectRecyclerView1.setAdapter(objectRvAdpater1);
        }
        catch (Exception e)
        {

        }
    }

    void fetchAllNotesFromDatabase()
    {
        try
        {
            Cursor objectCursor = objectDatabaseHandler1.readAllData();
            if (objectCursor.getCount() == 0)
            {
                Toast.makeText(this, "No data to show", Toast.LENGTH_SHORT).show();
            }

            else
            {
                while (objectCursor.moveToNext())
                {
                    String nameOfImage = objectCursor.getString(0);
                    byte [] imageBytes = objectCursor.getBlob(1);
                    String descriptionOfImage = objectCursor.getString(2);
                    String dateOfImage = objectCursor.getString(3);
                    String timeOfImage = objectCursor.getString(4);
                    String quantityOfImage = objectCursor.getString(5);
                    String locationOfImage = objectCursor.getString(6);

                    Bitmap objectBitmap = BitmapFactory.decodeByteArray(imageBytes,0,imageBytes.length);
                    objectModelClassList1.add(new ModelClass(nameOfImage,objectBitmap,descriptionOfImage,dateOfImage,timeOfImage,quantityOfImage,locationOfImage));
                    Toast.makeText(this," values in Database",Toast.LENGTH_SHORT).show();
                }
            }
        }
        catch (Exception e)
        {

        }


    }

    public void showMenu1(View view)
    {
        PopupMenu popupMenu = new PopupMenu(this,view);
        popupMenu.setOnMenuItemClickListener(this);
        popupMenu.inflate(R.menu.popup_menu);
        popupMenu.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.item1:
                Intent intent = new Intent(ShowImagesActivity2.this,ShowImagesActivity.class);
                startActivity(intent);
                return true;

            case R.id.item2:
                Intent intent1 = new Intent(ShowImagesActivity2.this,Account.class);
                startActivity(intent1);
                return true;

            case R.id.item3:
                Intent intent2 = new Intent(ShowImagesActivity2.this,ShowImagesActivity2.class);
                startActivity(intent2);
                return true;

            default:
                return false;
        }
    }

    public void Addlist1(View view)
    {
        Intent intent = new Intent(ShowImagesActivity2.this,MainActivity2.class);
        startActivity(intent);
    }
}