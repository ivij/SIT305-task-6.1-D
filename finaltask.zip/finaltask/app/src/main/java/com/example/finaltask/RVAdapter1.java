package com.example.finaltask;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RVAdapter1 extends RecyclerView.Adapter<RVAdapter1.RVViewHolderClass> {
    Context context;
    Activity activity;
    ArrayList<ModelClass> objectModelClassList1;

    public RVAdapter1(Context context, Activity activity, ArrayList<ModelClass> objectModelClassList1) {
        this.context = context;
        this.activity = activity;
        this.objectModelClassList1 = objectModelClassList1;
    }

    @NonNull
    @Override
    public RVViewHolderClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        try
        {
            return new RVViewHolderClass(LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_mylist, parent, false));

        } catch (Exception e)
        {
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
            return null;
        }
    }


    @Override
    public void onBindViewHolder(@NonNull RVViewHolderClass holder, int position) {
        try
        {
            holder.imageNameTV1.setText(objectModelClassList1.get(position).getImageName());
            holder.objectImageView1.setImageBitmap(objectModelClassList1.get(position).getImage());
            holder.imageDescriptionTV1.setText(objectModelClassList1.get(position).getImageDescription());
            holder.imageDateTV1.setText(objectModelClassList1.get(position).getImageDate());
            holder.imageTimeTV1.setText(objectModelClassList1.get(position).getImageTime());
            holder.imageQuantityTV1.setText(objectModelClassList1.get(position).getImageQuantity());
            holder.imageLocationTV1.setText(objectModelClassList1.get(position).getImageLocation());

        }
        catch (Exception e)
        {
            Toast.makeText(context,e.getMessage(),Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public int getItemCount() {
        return objectModelClassList1.size();
    }

    public static class RVViewHolderClass extends RecyclerView.ViewHolder {
        TextView imageNameTV1;
        ImageView objectImageView1;
        TextView imageDescriptionTV1;
        TextView imageDateTV1;
        TextView imageTimeTV1;
        TextView imageQuantityTV1;
        TextView imageLocationTV1;

        public RVViewHolderClass(@NonNull View itemView) {
            super(itemView);
            imageNameTV1 = itemView.findViewById(R.id.sr_imageDetailsTV1);
            objectImageView1 = itemView.findViewById(R.id.sr_imageTV1);
            imageDescriptionTV1 = itemView.findViewById(R.id.sr_imageDescriptionTV1);
            imageDateTV1 = itemView.findViewById(R.id.sr_imageDateTV1);
            imageTimeTV1 = itemView.findViewById(R.id.sr_imageTimeTV1);
            imageQuantityTV1 = itemView.findViewById(R.id.sr_imageQuantityTV1);
            imageLocationTV1 = itemView.findViewById(R.id.sr_imageLocationTV1);

        }
    }

}
