package com.example.finaltask;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class DatabaseHandler1 extends SQLiteOpenHelper {

    Context context;
    private static String DATABASE_NAME ="new_users .db";
    private static int DATABASE_VERSION = 1;
    private static String TableName;

    // private static String createTableQuery = "create table imageInfo (imageName TEXT" +
    //        ",image BLOB)";


    private ByteArrayOutputStream objectByteArrayOutputStream1;
    private byte[] imageInBytes1;

    public DatabaseHandler1(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try
        {
            String createTableQuery = "create table imageInforma (imageName TEXT" +
                    ",image BLOB" +
                    ",imageDescription TEXT" +
                    ",imageDate TEXT" +
                    ",imageTime TEXT" +
                    ",imageQuantity TEXT" +
                    ",imageLocation TEXT)";
            db.execSQL(createTableQuery);
            Toast.makeText(context,"Table created success",Toast.LENGTH_SHORT).show();
        }
        catch (Exception e)
        {
            Toast.makeText(context,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        try
        {
            db.execSQL("DROP TABLE IF EXISTS imageInfoma");
            onCreate(db);
        }

        catch(Exception e)
        {
            Toast.makeText(context,e.getMessage(),Toast.LENGTH_SHORT).show();
        }


    }

    public void storeImage(ModelClass objectModelClass)
    {
        try
        {
            SQLiteDatabase objectSqLiteDatabase = this.getWritableDatabase();
            Bitmap imageToStoreBitmap = objectModelClass.getImage();
            objectByteArrayOutputStream1 = new ByteArrayOutputStream();
            imageToStoreBitmap.compress(Bitmap.CompressFormat.JPEG,100,objectByteArrayOutputStream1);

            imageInBytes1 = objectByteArrayOutputStream1.toByteArray();
            ContentValues objectContentValues = new ContentValues();

            objectContentValues.put("imageName",objectModelClass.getImageName());
            objectContentValues.put("image",imageInBytes1);
            objectContentValues.put("imageDescription",objectModelClass.getImageDescription());
            objectContentValues.put("imageDate",objectModelClass.getImageDate());
            objectContentValues.put("imageTime",objectModelClass.getImageTime());
            objectContentValues.put("imageQuantity",objectModelClass.getImageQuantity());
            objectContentValues.put("imageLocation",objectModelClass.getImageLocation());

            long checkIfQueryRuns = objectSqLiteDatabase.insert("imageInforma",null,objectContentValues);
            if(checkIfQueryRuns!=-1)
            {
                Toast.makeText(context,"Data added into our table",Toast.LENGTH_SHORT).show();
                //  objectSqLiteDatabase.close();
            }

            else
            {
                Toast.makeText(context,"Fails to add data",Toast.LENGTH_SHORT).show();
            }

        }
        catch (Exception e)
        {
            Toast.makeText(context,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    public ArrayList<ModelClass> getAllImagesData()
    {
        try
        {
            SQLiteDatabase objectSqLiteDatabase = this.getReadableDatabase();
            ArrayList<ModelClass> objectModelClassList1 = new ArrayList<>();
            Cursor objectCursor = objectSqLiteDatabase.rawQuery("SELECT * FROM imageInforma",null);
            if(objectCursor.getCount() ==0)
            {
                Toast.makeText(context,"No values in Database",Toast.LENGTH_SHORT).show();
                return null;

            }
            else
            {
                while (objectCursor.moveToNext())
                {
                    String nameOfImage = objectCursor.getString(0);
                    byte [] imageBytes = objectCursor.getBlob(1);
                    String descriptionOfImage = objectCursor.getString(2);
                    String dateOfImage = objectCursor.getString(3);
                    String timeOfImage = objectCursor.getString(4);
                    String quantityOfImage = objectCursor.getString(5);
                    String locationOfImage = objectCursor.getString(6);

                    Bitmap objectBitmap = BitmapFactory.decodeByteArray(imageBytes,0,imageBytes.length);
                    objectModelClassList1.add(new ModelClass(nameOfImage,objectBitmap,descriptionOfImage,dateOfImage,timeOfImage,quantityOfImage,locationOfImage));
                    Toast.makeText(context," values in Database",Toast.LENGTH_SHORT).show();
                }
                return objectModelClassList1;
            }
        }
        catch (Exception e)
        {
            Toast.makeText(context,e.getMessage(),Toast.LENGTH_SHORT).show();
            return null;
        }
    }



    Cursor readAllData() {

        try
        {
            String query = "select * from imageInforma";
            SQLiteDatabase objectSqLiteDatabase = this.getReadableDatabase();
            Cursor cursor = null;
            if (objectSqLiteDatabase != null)
            {
                cursor = objectSqLiteDatabase.rawQuery(query, null);
            }
            return cursor;
        }

        catch(Exception e)
        {
            Toast.makeText(context,e.getMessage(),Toast.LENGTH_SHORT).show();
            return null;
        }
    }
}
