package com.example.finaltask;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class ShowImagesActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener{

    private DatabaseHandler objectDatabaseHandler;
    private RecyclerView objectRecyclerView;
    private ArrayList<ModelClass> objectModelClassList;
    private RVAdapter objectRvAdpater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_images);

        fetchAllNotesFromDatabase();
        try
        {
            objectRecyclerView = findViewById(R.id.imagesRV);
            objectDatabaseHandler = new DatabaseHandler(this);
            objectModelClassList = new ArrayList<ModelClass>();

            objectRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            objectRvAdpater = new RVAdapter(this,ShowImagesActivity.this,objectDatabaseHandler.getAllImagesData());
            // objectRecyclerView.setHasFixedSize(true);
            objectRecyclerView.setAdapter(objectRvAdpater);
        }


        catch (Exception e)
        {

        }


    }
    public void getData(View view)
    {
        try
        {
            objectRvAdpater = new RVAdapter(this,ShowImagesActivity.this,objectDatabaseHandler.getAllImagesData());
            objectRecyclerView.setHasFixedSize(true);
            objectRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            objectRecyclerView.setAdapter(objectRvAdpater);
        }
        catch (Exception e)
        {

        }
    }

    void fetchAllNotesFromDatabase()
    {
        try
        {
            Cursor objectCursor = objectDatabaseHandler.readAllData();
            if (objectCursor.getCount() == 0)
            {
                Toast.makeText(this, "No data to show", Toast.LENGTH_SHORT).show();
            }

            else
            {
                while (objectCursor.moveToNext())
                {
                    String nameOfImage = objectCursor.getString(0);
                    byte [] imageBytes = objectCursor.getBlob(1);
                    String descriptionOfImage = objectCursor.getString(2);
                    String dateOfImage = objectCursor.getString(3);
                    String timeOfImage = objectCursor.getString(4);
                    String quantityOfImage = objectCursor.getString(5);
                    String locationOfImage = objectCursor.getString(6);

                    Bitmap objectBitmap = BitmapFactory.decodeByteArray(imageBytes,0,imageBytes.length);
                    objectModelClassList.add(new ModelClass(nameOfImage,objectBitmap,descriptionOfImage,dateOfImage,timeOfImage,quantityOfImage,locationOfImage));
                    Toast.makeText(this," values in Database",Toast.LENGTH_SHORT).show();
                }
            }
        }
        catch (Exception e)
        {

        }


    }

    public void showMenu(View view)
    {
        PopupMenu popupMenu = new PopupMenu(this,view);
        popupMenu.setOnMenuItemClickListener(this);
        popupMenu.inflate(R.menu.popup_menu);
        popupMenu.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.item1:
                Intent intent = new Intent(ShowImagesActivity.this,ShowImagesActivity.class);
                startActivity(intent);
                return true;

            case R.id.item2:
                Intent intent1 = new Intent(ShowImagesActivity.this,Account.class);
                startActivity(intent1);
                return true;

            case R.id.item3:
                Intent intent2 = new Intent(ShowImagesActivity.this,ShowImagesActivity2.class);
                startActivity(intent2);
                return true;

            default:
                return false;
        }
    }

    public void Addlist(View view)
    {
        Intent intent = new Intent(ShowImagesActivity.this,MainActivity3.class);
        startActivity(intent);
    }
}
