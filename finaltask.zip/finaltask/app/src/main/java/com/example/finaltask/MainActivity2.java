package com.example.finaltask;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    private EditText imageDetailsET1;
    private ImageView objectImageView1;
    private EditText imageDescriptionET1;
    private CalendarView calendarView1;
    private EditText imageTimeET1;
    private EditText imageQuantityET1;
    private EditText imageLocationET1;
    public String date1;

    private static final int PICK_IMAGE_REQUEST = 200;
    private Uri imageFilePath1;
    private Bitmap imageToStore1;

    DatabaseHandler1 objectDatabaseHandler1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        try
        {
            imageDetailsET1 = findViewById(R.id.imageNameET1);
            objectImageView1 = findViewById(R.id.image1);
            imageDescriptionET1 = findViewById(R.id.imageDescriptionET1);
            calendarView1 = findViewById(R.id.calendarView1);
            imageTimeET1 = findViewById(R.id.imageTimeET1);
            imageQuantityET1 = findViewById(R.id.imageQuantityET1);
            imageLocationET1 = findViewById(R.id.imageLocationET1);

            calendarView1.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                @Override
                public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                    date1 = dayOfMonth + "/" + (month+1) + "/" + year;
                }
            });

            objectDatabaseHandler1 = new DatabaseHandler1(this);

        }
        catch (Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }


    public void chooseImage1(View objectView)
    {
        try
        {
            confirmDialog();

        }
        catch (Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try
        {
            super.onActivityResult(requestCode, resultCode, data);
            if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data!=null && data.getData()!=null);
            {
                imageFilePath1 = data.getData();
                imageToStore1 = MediaStore.Images.Media.getBitmap(getContentResolver(),imageFilePath1);

                objectImageView1.setImageBitmap(imageToStore1);
            }
        }
        catch (Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }
    public void storeImage1(View view)
    {
        try
        {
            if(!imageDetailsET1.getText().toString().isEmpty() && objectImageView1.getDrawable()!=null && imageToStore1!=null  && !imageDescriptionET1.getText().toString().isEmpty() && date1!=null && !imageTimeET1.getText().toString().isEmpty() && !imageQuantityET1.getText().toString().isEmpty() && !imageLocationET1.getText().toString().isEmpty())
            {
                objectDatabaseHandler1.storeImage(new ModelClass(imageDetailsET1.getText().toString(),imageToStore1,imageDescriptionET1.getText().toString(),date1,imageTimeET1.getText().toString(),imageQuantityET1.getText().toString(),imageLocationET1.getText().toString()));
            }
            else
            {
                Toast.makeText(this,"Please select image and name",Toast.LENGTH_SHORT).show();
            }

        }
        catch (Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    public void moveToShowActivity1(View view)
    {
        startActivity(new Intent(this,ShowImagesActivity2.class));
    }

    void confirmDialog()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Allow the app to access photos,media and files on your device?");
        builder.setPositiveButton("ALLOW", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Intent objectIntent = new Intent();
                objectIntent.setType("image/*");

                objectIntent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(objectIntent,PICK_IMAGE_REQUEST);


            }
        });

        builder.setNegativeButton("DENY", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }
}