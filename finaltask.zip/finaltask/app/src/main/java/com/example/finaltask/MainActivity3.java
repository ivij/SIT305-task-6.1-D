package com.example.finaltask;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {
    private EditText imageDetailsET;
    private ImageView objectImageView;
    private EditText imageDescriptionET;
    private CalendarView calendarView;
    private EditText imageTimeET;
    private EditText imageQuantityET;
    private EditText imageLocationET;
    public String date;

    private static final int PICK_IMAGE_REQUEST = 100;
    private Uri imageFilePath;
    private Bitmap imageToStore;

    DatabaseHandler objectDatabaseHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        try
        {
            imageDetailsET = findViewById(R.id.imageNameET);
            objectImageView = findViewById(R.id.image);
            imageDescriptionET = findViewById(R.id.imageDescriptionET);
            calendarView = findViewById(R.id.calendarView);
            imageTimeET = findViewById(R.id.imageTimeET);
            imageQuantityET = findViewById(R.id.imageQuantityET);
            imageLocationET = findViewById(R.id.imageLocationET);

            calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                @Override
                public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                    date = dayOfMonth + "/" + (month+1) + "/" + year;
                }
            });

            objectDatabaseHandler = new DatabaseHandler(this);

        }
        catch (Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }


    public void chooseImage(View objectView)
    {
        try
        {
            confirmDialog();
        }
        catch (Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try
        {
            super.onActivityResult(requestCode, resultCode, data);
            if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data!=null && data.getData()!=null);
            {
                imageFilePath = data.getData();
                imageToStore = MediaStore.Images.Media.getBitmap(getContentResolver(),imageFilePath);

                objectImageView.setImageBitmap(imageToStore);
            }
        }
        catch (Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }
    public void storeImage(View view)
    {
        try
        {
            if(!imageDetailsET.getText().toString().isEmpty() && objectImageView.getDrawable()!=null && imageToStore!=null  && !imageDescriptionET.getText().toString().isEmpty() && date!=null && !imageTimeET.getText().toString().isEmpty() && !imageQuantityET.getText().toString().isEmpty() && !imageLocationET.getText().toString().isEmpty())
            {
                objectDatabaseHandler.storeImage(new ModelClass(imageDetailsET.getText().toString(),imageToStore,imageDescriptionET.getText().toString(),date,imageTimeET.getText().toString(),imageQuantityET.getText().toString(),imageLocationET.getText().toString()));
            }
            else
            {
                Toast.makeText(this,"Please select image and name",Toast.LENGTH_SHORT).show();
            }

        }
        catch (Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    public void moveToShowActivity(View view)
    {
        startActivity(new Intent(this,ShowImagesActivity.class));
    }

    void confirmDialog()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Allow the app to access photos,media and files on your device?");
        builder.setPositiveButton("ALLOW", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Intent objectIntent = new Intent();
                objectIntent.setType("image/*");

                objectIntent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(objectIntent,PICK_IMAGE_REQUEST);


            }
        });

        builder.setNegativeButton("DENY", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }
}