package com.example.finaltask;

import android.graphics.Bitmap;

public class ModelClass {

    private String imageName;
    private Bitmap image;
    private String imageDescription;
    private String imageDate;
    private String imageTime;
    private String imageQuantity;
    private String imageLocation;

    public ModelClass(String imageName, Bitmap image, String imageDescription, String imageDate, String imageTime, String imageQuantity, String imageLocation) {
        this.imageName = imageName;
        this.image = image;
        this.imageDescription = imageDescription;
        this.imageDate = imageDate;
        this.imageTime = imageTime;
        this.imageQuantity = imageQuantity;
        this.imageLocation = imageLocation;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public String getImageDescription() {
        return imageDescription;
    }

    public void setImageDescription(String imageDescription) {
        this.imageDescription = imageDescription;
    }

    public String getImageDate() {
        return imageDate;
    }

    public void setImageDate(String imageDate) {
        this.imageDate = imageDate;
    }

    public String getImageTime() {
        return imageTime;
    }

    public void setImageTime(String imageTime) {
        this.imageTime = imageTime;
    }

    public String getImageQuantity() {
        return imageQuantity;
    }

    public void setImageQuantity(String imageQuantity) {
        this.imageQuantity = imageQuantity;
    }

    public String getImageLocation() {
        return imageLocation;
    }

    public void setImageLocation(String imageLocation) {
        this.imageLocation = imageLocation;
    }
}
