package com.example.finaltask;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RVAdapter extends RecyclerView.Adapter<RVAdapter.RVViewHolderClass> {
    Context context;
    Activity activity;
    ArrayList<ModelClass> objectModelClassList;

    public RVAdapter(Context context, Activity activity, ArrayList<ModelClass> objectModelClassList) {
        this.context = context;
        this.activity = activity;
        this.objectModelClassList = objectModelClassList;
    }

    @NonNull
    @Override
    public RVViewHolderClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        try
        {
            return new RVViewHolderClass(LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row, parent, false));

        } catch (Exception e)
        {
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
            return null;
        }
    }


    @Override
    public void onBindViewHolder(@NonNull RVViewHolderClass holder, int position) {
        try
        {
            holder.imageNameTV.setText(objectModelClassList.get(position).getImageName());
            holder.objectImageView.setImageBitmap(objectModelClassList.get(position).getImage());
            holder.imageDescriptionTV.setText(objectModelClassList.get(position).getImageDescription());
            holder.imageDateTV.setText(objectModelClassList.get(position).getImageDate());
            holder.imageTimeTV.setText(objectModelClassList.get(position).getImageTime());
            holder.imageQuantityTV.setText(objectModelClassList.get(position).getImageQuantity());
            holder.imageLocationTV.setText(objectModelClassList.get(position).getImageLocation());

        }
        catch (Exception e)
        {
            Toast.makeText(context,e.getMessage(),Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public int getItemCount() {
        return objectModelClassList.size();
    }

    public static class RVViewHolderClass extends RecyclerView.ViewHolder {
        TextView imageNameTV;
        ImageView objectImageView;
        TextView imageDescriptionTV;
        TextView imageDateTV;
        TextView imageTimeTV;
        TextView imageQuantityTV;
        TextView imageLocationTV;

        public RVViewHolderClass(@NonNull View itemView) {
            super(itemView);
            imageNameTV = itemView.findViewById(R.id.sr_imageDetailsTV);
            objectImageView = itemView.findViewById(R.id.sr_imageTV);
            imageDescriptionTV = itemView.findViewById(R.id.sr_imageDescriptionTV);
            imageDateTV = itemView.findViewById(R.id.sr_imageDateTV);
            imageTimeTV = itemView.findViewById(R.id.sr_imageTimeTV);
            imageQuantityTV = itemView.findViewById(R.id.sr_imageQuantityTV);
            imageLocationTV = itemView.findViewById(R.id.sr_imageLocationTV);

        }
    }

}
